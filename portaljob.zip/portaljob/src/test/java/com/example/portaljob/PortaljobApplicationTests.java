package com.example.portaljob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortaljobApplicationTests {

	@Test
	void contextLoads() {
	}

}
