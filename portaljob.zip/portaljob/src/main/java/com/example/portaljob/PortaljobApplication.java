package com.example.portaljob;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PortaljobApplication {

	public static void main(String[] args) {
		SpringApplication.run(PortaljobApplication.class, args);
	}

}
